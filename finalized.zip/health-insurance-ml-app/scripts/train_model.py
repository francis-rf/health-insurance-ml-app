
import pandas as pd
import joblib
import os
import sys, os
import logging
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.models.train import train_linear_models, train_xgboost_model, tune_xgboost_model, evaluate_model, save_model
def main():
    X_train = pd.read_csv('data/processed/X_train.csv')
    X_test = pd.read_csv('data/processed/X_test.csv')
    y_train = pd.read_csv('data/processed/y_train.csv').squeeze()
    y_test = pd.read_csv('data/processed/y_test.csv').squeeze()

    # Train models
    models = train_linear_models(X_train, y_train)
    xgb_model = train_xgboost_model(X_train, y_train)
    tuned_xgb = tune_xgboost_model(xgb_model, X_train, y_train)

    # Add XGBoost models to the dictionary
    models['XGBoost'] = xgb_model
    models['TunedXGBoost'] = tuned_xgb

    # Evaluate all models and store their scores
    model_scores = {}
    for name, model in models.items():
        _, _, r2 = evaluate_model(model, X_test, y_test)
        model_scores[name] = r2

    # Select best model based on R² score
    best_model_name = max(model_scores, key=model_scores.get)
    best_model = models[best_model_name]
    logging.info(f"🏆 Best Model: {best_model_name} with R² = {model_scores[best_model_name]:.4f}")

    # Save best model
    save_model(best_model, 'models/best_model.pkl')

    # Save feature columns
    pd.Series(X_train.columns).to_csv('models/feature_columns.csv', index=False)

if __name__ == "__main__":
    main()
