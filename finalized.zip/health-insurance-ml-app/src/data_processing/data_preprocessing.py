import os
import logging
from typing import Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import joblib

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Display options
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 120)
sns.set_theme(style='whitegrid')

# ===========================
# Load Data
# ===========================
def load_data(path: str) -> pd.DataFrame:
    """
    Load dataset from CSV or Excel file.
    Args:
        path (str): File path of dataset.
    Returns:
        pd.DataFrame: Loaded dataset.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    if path.endswith('.csv'):
        return pd.read_csv(path)
    elif path.endswith('.xlsx'):
        return pd.read_excel(path, engine='openpyxl')
    else:
        raise ValueError('Unsupported file format. Use CSV or XLSX.')

# ===========================
# Feature Engineering
# ===========================
# def generate_risk_features(df: pd.DataFrame) -> pd.DataFrame:
#     """
#     Generate normalized risk score from medical history.
#     """
#     risk_scores = {
#         'diabetes': 6,
#         'high blood pressure': 6,
#         'no disease': 0,
#         'thyroid': 5,
#         'heart disease': 8
#     }
#     df[['disease1', 'disease2']] = df['medical_history'].str.split(' & ', expand=True)
#     df['total_risk'] = sum(df[col].str.lower().map(risk_scores).fillna(0) for col in ['disease1', 'disease2'])
#     min_, max_ = df['total_risk'].min(), df['total_risk'].max()
#     df['normalized_risk'] = (df['total_risk'] - min_) / (max_ - min_)
#     return df
def generate_risk_features(df: pd.DataFrame) -> pd.DataFrame:
    risk_scores = {
        'diabetes': 6,
        'high blood pressure': 6,
        'no disease': 0,
        'thyroid': 5,
        'heart disease': 8
    }

    split_diseases = df['medical_history'].str.lower().str.split(' & ', expand=True)
    if split_diseases.shape[1] == 1:
        split_diseases[1] = "no disease"

    df[['disease1', 'disease2']] = split_diseases

    df['total_risk'] = sum(df[col].map(risk_scores).fillna(0) for col in ['disease1', 'disease2'])

    # Safe normalization
    min_, max_ = df['total_risk'].min(), df['total_risk'].max()
    if min_ == max_:
        df['normalized_risk'] = 1  # or any default like 0.5
    else:
        df['normalized_risk'] = (df['total_risk'] - min_) / (max_ - min_)

    return df




# ===========================
# Feature Selection
# ===========================
def drop_unnecessary_features(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Drop specified columns from the dataset.
    """
    return df.drop(columns, axis=1)

# ===========================
# Feature Encoding
# ===========================
def encode_categorical_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Encode ordinal and nominal categorical features.
    """
    df = df.copy()
    df['insurance_plan'] = df['insurance_plan'].map({'Bronze': 1, 'Silver': 2, 'Gold': 3})
    df['income_level'] = df['income_level'].map({'<10L': 1, '10L - 25L': 2, '25L - 40L': 3, '> 40L': 4})
    df = pd.get_dummies(df, columns=['gender','bmi_category','region','marital_status','smoking_status','employment_status'], drop_first=True, dtype=int)
    return df

# ===========================
# Correlation Matrix
# ===========================
def plot_correlation_matrix(df: pd.DataFrame, figsize: Tuple[int, int] = (24, 16)) -> None:
    """
    Plot correlation matrix for numerical features.
    """
    corr = df.corr()
    plt.figure(figsize=figsize)
    sns.heatmap(corr, annot=True, cmap='vlag', center=0, fmt='.2f')
    plt.title('Correlation Matrix')
    plt.tight_layout()
    plt.show()

# ===========================
# Feature Scaling
# ===========================
def scale_features(df: pd.DataFrame, target_col: str, cols_to_scale: list) -> Tuple[pd.DataFrame, pd.Series, MinMaxScaler]:
    """
    Scale selected features and separate target.
    """
    X = df.drop(target_col, axis=1).copy()
    y = df[target_col].copy()
    scaler = MinMaxScaler()
    X[cols_to_scale] = scaler.fit_transform(X[cols_to_scale])
    return X, y, scaler

# ===========================
# Variance Inflation Factor
# ===========================
def calculate_vif(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate VIF for numeric features.
    """
    numeric_df = df.select_dtypes(include=['int64', 'float64']).copy()
    vif_data = pd.DataFrame()
    vif_data['Feature'] = numeric_df.columns
    vif_data['VIF'] = [variance_inflation_factor(numeric_df.values, i) for i in range(numeric_df.shape[1])]
    return vif_data

# ===========================
# Train-Test Split & Save
# ===========================
def split_and_save_data(X: pd.DataFrame, y: pd.Series, scaler: MinMaxScaler,
                        output_dir: str = '../data/processed/',
                        test_size: float = 0.2, random_state: int = 42) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Split data and save train/test sets and scaler.
    """
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    os.makedirs(output_dir, exist_ok=True)
    X_train.to_csv(os.path.join(output_dir, 'X_train.csv'), index=False)
    X_test.to_csv(os.path.join(output_dir, 'X_test.csv'), index=False)
    y_train.to_csv(os.path.join(output_dir, 'y_train.csv'), index=False)
    y_test.to_csv(os.path.join(output_dir, 'y_test.csv'), index=False)
    joblib.dump(scaler, os.path.join(output_dir, 'scaler.pkl'))
    logging.info('✅ Data split and saved successfully.')
    return X_train, X_test, y_train, y_test

logging.info("✅ data_preprocessing.py cleaned and improved.")
