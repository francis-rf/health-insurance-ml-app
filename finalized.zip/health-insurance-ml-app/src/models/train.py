# ===========================
# Imports
# ===========================
import os
import logging
import joblib
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from xgboost import XGBRegressor
from sklearn.model_selection import cross_val_score, RandomizedSearchCV
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# ===========================
# Model Training
# ===========================
def train_linear_models(X_train, y_train):
    """
    Train Linear, Ridge, and Lasso regression models.
    Returns a dictionary of trained models.
    """
    models = {
        'LinearRegression': LinearRegression(),
        'Ridge': Ridge(),
        'Lasso': Lasso()
    }

    for name, model in models.items():
        model.fit(X_train, y_train)
        scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
        logging.info(f"{name}: Mean R² = {scores.mean():.4f}")

    return models

def train_xgboost_model(X_train, y_train):
    """
    Train an XGBoost regressor and return the model.
    """
    model = XGBRegressor(random_state=42, verbosity=0)
    model.fit(X_train, y_train)
    scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
    logging.info(f"XGBoost: Mean R² = {scores.mean():.4f}")
    return model

# ===========================
# Hyperparameter Tuning
# ===========================
def tune_xgboost_model(model, X_train, y_train):
    """
    Tune XGBoost hyperparameters using RandomizedSearchCV.
    """
    param_grid = {
        'n_estimators': [20, 40, 50],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [3, 4, 5],
    }

    search = RandomizedSearchCV(model, param_grid, cv=3, scoring='r2', n_iter=10)
    search.fit(X_train, y_train)

    logging.info(f"Best Params: {search.best_params_}")
    logging.info(f"Best Score: {search.best_score_:.4f}")

    return search.best_estimator_

# ===========================
# Evaluation
# ===========================
def evaluate_model(model, X_test, y_test):
    """
    Evaluate model performance on test data.
    Returns MAE, RMSE, and R².
    """
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = root_mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    logging.info(f"MAE: {mae:.4f}")
    logging.info(f"RMSE: {rmse:.4f}")
    logging.info(f"R²: {r2:.4f}")

    return mae, rmse, r2

# ===========================
# Save Model
# ===========================
def save_model(model, output_path='../models/best_model.pkl'):
    """
    Save trained model to disk using joblib.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    joblib.dump(model, output_path)
    logging.info(f"✅ Model saved at {output_path}")

