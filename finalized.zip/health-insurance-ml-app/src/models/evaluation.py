
# # ===========================
# # Imports
# # ===========================
# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# import seaborn as sns
# import joblib
# from sklearn.metrics import mean_absolute_error, root_mean_squared, r2_score

# x_test_path = '../data/processed/X_test.csv'
# y_test_path = '../data/processed/y_test.csv'
# model_path  = '../models/best_model.pkl'

# # ===========================
# # Load Data & Model
# # ===========================
# def load_model(x_test_path: str, y_test_path: str, model_path:str):
#     '''
#     loads the test data and trained model
#     returns data and model
#     '''
#     X_test = pd.read_csv(x_test_path)
#     y_test = pd.read_csv(y_test_path)

#     model = joblib.load(model_path)

#     return X_test, y_test, model

# # ===========================
# # Evaluation Metrics
# # ===========================
# def evaluate_model(model, X_test, y_test):
#     """
#     Evaluate model performance with MAE, RMSE, and R².
#     """
#     y_pred = model.predict(X_test)
    
#     mae = mean_absolute_error(y_test, y_pred)
#     rmse = root_mean_squared(y_test, y_pred)
#     r2 = r2_score(y_test, y_pred)
    
#     print(f"MAE: {mae:.4f}")
#     print(f"RMSE: {rmse:.4f}")
#     print(f"R2: {r2:.4f}")
    
#     return y_pred, mae, rmse, r2

# # ===========================
# # Predicted vs Actual Plot
# # ===========================

# def plot_results(y_test,y_pred):
#     plt.figure(figsize=(6,6))
#     plt.scatter(y_test, y_pred, alpha=0.6)
#     plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
#     plt.xlabel('Actual Premium')
#     plt.ylabel('Predicted Premium')
#     plt.title('Predicted vs Actual Premiums')
#     plt.show()

# # ===========================
# # Error Distribution
# # ===========================
# def error_distribution(y_test,y_pred):
#     errors = y_test.values.flatten() - y_pred
#     sns.histplot(errors, kde=True, bins=30)
#     plt.title('Error Distribution (Actual - Predicted)')
#     plt.xlabel('Error')
#     plt.show()

# # ===========================
# # Business Criteria Check
# # ===========================
# # - Accuracy ≥ 97%
# # - At least 95% of predictions have <10% error
# def businees_criteria_check(y_test,y_pred):
#     pct_errors = np.abs((y_test.values.flatten() - y_pred) / y_test.values.flatten()) * 100
#     # Business rule check
#     within_10pct = np.mean(pct_errors < 10) * 100
#     print(f'✅ Predictions within 10% error: {within_10pct:.2f}%')

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# File paths
x_test_path = '../data/processed/X_test.csv'
y_test_path = '../data/processed/y_test.csv'
model_path  = '../models/best_model.pkl'

# ===========================
# Load Data & Model
# ===========================
def load_model(x_test_path: str, y_test_path: str, model_path: str):
    """
    Load test data and trained model.
    Returns:
        X_test (pd.DataFrame), y_test (pd.Series), model (sklearn model)
    """
    X_test = pd.read_csv(x_test_path)
    y_test = pd.read_csv(y_test_path)
    model = joblib.load(model_path)
    return X_test, y_test, model

# ===========================
# Evaluation Metrics
# ===========================
def evaluate_model(model, X_test, y_test):
    """
    Evaluate model performance with MAE, RMSE, and R².
    Returns:
        y_pred, MAE, RMSE, R²
    """
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = root_mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    logging.info(f"MAE: {mae:.4f}")
    logging.info(f"RMSE: {rmse:.4f}")
    logging.info(f"R2: {r2:.4f}")
    return y_pred, mae, rmse, r2

# ===========================
# Predicted vs Actual Plot
# ===========================
def plot_results(y_test, y_pred):
    plt.figure(figsize=(6,6))
    plt.scatter(y_test, y_pred, alpha=0.6)
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
    plt.xlabel('Actual Premium')
    plt.ylabel('Predicted Premium')
    plt.title('Predicted vs Actual Premiums')
    plt.tight_layout()
    plt.show()

# ===========================
# Error Distribution
# ===========================
def error_distribution(y_test, y_pred):
    errors = y_test.values.flatten() - y_pred
    sns.histplot(errors, kde=True, bins=30)
    plt.title('Error Distribution (Actual - Predicted)')
    plt.xlabel('Error')
    plt.tight_layout()
    plt.show()

# ===========================
# Business Criteria Check
# ===========================
def business_criteria_check(y_test, y_pred):
    """
    Check if predictions meet business criteria:
    - At least 95% of predictions have <10% error
    """
    pct_errors = np.abs((y_test.values.flatten() - y_pred) / y_test.values.flatten()) * 100
    within_10pct = np.mean(pct_errors < 10) * 100
    logging.info(f"✅ Predictions within 10% error: {within_10pct:.2f}%")
    return within_10pct

# ===========================
# Main Execution
# ===========================
def main():
    X_test, y_test, model = load_model(x_test_path, y_test_path, model_path)
    y_pred, mae, rmse, r2 = evaluate_model(model, X_test, y_test)
    plot_results(y_test, y_pred)
    error_distribution(y_test, y_pred)
    business_criteria_check(y_test, y_pred)

if __name__ == "__main__":
    main()
